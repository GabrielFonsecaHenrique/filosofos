﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoRafa
{
    class Filosofo
    {
        public bool _garfoDireita { get; set; }
        public bool _garfoEsquerda { get; set; }
        public bool _garfoDireitaLimpo { get; set; }
        public bool _garfoEsquerdaLimpo { get; set; }
        public bool _fome { get; set; }
        public bool _isDormindo { get; set; }
        public bool _isComendo { get; set; }
        public bool _ticketDireita { get; set; }
        public bool _ticketEsquerda { get; set; }
        public Filosofo vizinhoDireita { get; set; }
        public Filosofo vizinhoEsquerda { get; set; }

        public Filosofo()
        {
            _fome = false;
            _garfoDireita = true;
            _garfoEsquerda = false;
            _ticketDireita = false;
            _ticketEsquerda = true;
            _isDormindo = true;
            _isComendo = false;
        }

        public void comecarComer()
        {
            _fome = true;
            _isDormindo = false;

            if (verificarGarfos())
                comer();

        }

        public void pararComer()
        {
            _isComendo = false;
            _garfoEsquerdaLimpo = false;
            _garfoDireitaLimpo = false;
        }

        private bool verificarGarfos()
        {
            if (_garfoDireita && _garfoEsquerda)
                return true;

            if (pedirGarfo())
                return true;

            return false;
        }

        private bool pedirGarfo()
        {

            if (!_garfoDireita)
                pedirGarfoD();

            if (!_garfoEsquerda)
                pedirGarfoE();

            if (_garfoDireita && _garfoEsquerda)
                return true;
            return false;
        }

        private void pedirGarfoD()
        {
            this._ticketDireita = false;
            vizinhoDireita.receberTicketE();

            if (!(vizinhoDireita._isComendo) && !(vizinhoDireita._garfoEsquerdaLimpo))
            {
                enviarGarfoD();
                receberGarfoD();
            }
        }

        private void pedirGarfoE()
        {
            this._ticketEsquerda = false;
            vizinhoEsquerda.receberTicketD();

            if (!(vizinhoEsquerda._isComendo) && !(vizinhoEsquerda._garfoDireitaLimpo))
            {
                enviarGarfoE();
                receberGarfoE();
            }
        }

        private void enviarGarfoD()
        {
            vizinhoEsquerda.receberGarfoD();
            _garfoDireita = false;
        }

        private void enviarGarfoE()
        {
            _garfoDireita = false;
            vizinhoDireita.receberGarfoE();
        }

        private void vizinhoDPediu()
        {
            //Vizinho da direita pediu o ticket, automaticamente o vizinho da esquerda tem o ticket da direita true
            vizinhoEsquerda._ticketDireita = true;
            if (_ticketDireita && !_isComendo)
                enviarGarfoD();
        }

        private void vizinhoEPediu()
        {
            vizinhoDireita._ticketEsquerda = true;
            if (_ticketDireita && !_isComendo)
                enviarGarfoD();
        }

        private void comer()
        {
            _isComendo = true;
        }

        private void receberTicketD()
        {
            _ticketDireita = true;
        }

        private void receberTicketE()
        {
            _ticketEsquerda = true;
        }

        private void receberGarfoD()
        {
            _garfoDireita = true;
            _garfoDireitaLimpo = true;
        }

        private void receberGarfoE()
        {
            _garfoEsquerda = true;
            _garfoEsquerdaLimpo = true;
        }

    }
}
