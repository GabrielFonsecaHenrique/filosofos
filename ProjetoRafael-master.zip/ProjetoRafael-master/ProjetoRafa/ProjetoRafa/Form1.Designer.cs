﻿namespace ProjetoRafa
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLucas = new System.Windows.Forms.Button();
            this.btnCarol = new System.Windows.Forms.Button();
            this.btnGabriel = new System.Windows.Forms.Button();
            this.gabTD = new System.Windows.Forms.PictureBox();
            this.lucasGSE = new System.Windows.Forms.PictureBox();
            this.carolGSE = new System.Windows.Forms.PictureBox();
            this.gabGSE = new System.Windows.Forms.PictureBox();
            this.lucasGLD = new System.Windows.Forms.PictureBox();
            this.carolGLD = new System.Windows.Forms.PictureBox();
            this.gabGLD = new System.Windows.Forms.PictureBox();
            this.gabrielH = new System.Windows.Forms.PictureBox();
            this.carolineA = new System.Windows.Forms.PictureBox();
            this.lucasD = new System.Windows.Forms.PictureBox();
            this.carolTE = new System.Windows.Forms.PictureBox();
            this.lucasTE = new System.Windows.Forms.PictureBox();
            this.carolTD = new System.Windows.Forms.PictureBox();
            this.lucasTD = new System.Windows.Forms.PictureBox();
            this.gabTE = new System.Windows.Forms.PictureBox();
            this.carolGLE = new System.Windows.Forms.PictureBox();
            this.carolGSD = new System.Windows.Forms.PictureBox();
            this.gabGSD = new System.Windows.Forms.PictureBox();
            this.gabGLE = new System.Windows.Forms.PictureBox();
            this.lucasGSD = new System.Windows.Forms.PictureBox();
            this.lucasGLE = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.gabTD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lucasGSE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carolGSE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gabGSE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lucasGLD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carolGLD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gabGLD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gabrielH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carolineA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lucasD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carolTE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lucasTE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carolTD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lucasTD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gabTE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carolGLE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carolGSD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gabGSD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gabGLE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lucasGSD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lucasGLE)).BeginInit();
            this.SuspendLayout();
            // 
            // btnLucas
            // 
            this.btnLucas.Location = new System.Drawing.Point(126, 370);
            this.btnLucas.Name = "btnLucas";
            this.btnLucas.Size = new System.Drawing.Size(136, 40);
            this.btnLucas.TabIndex = 3;
            this.btnLucas.Text = "começar a comer";
            this.btnLucas.UseVisualStyleBackColor = true;
            this.btnLucas.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnCarol
            // 
            this.btnCarol.Location = new System.Drawing.Point(341, 138);
            this.btnCarol.Name = "btnCarol";
            this.btnCarol.Size = new System.Drawing.Size(120, 23);
            this.btnCarol.TabIndex = 4;
            this.btnCarol.Text = "começar a comer";
            this.btnCarol.UseVisualStyleBackColor = true;
            this.btnCarol.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnGabriel
            // 
            this.btnGabriel.Location = new System.Drawing.Point(551, 367);
            this.btnGabriel.Name = "btnGabriel";
            this.btnGabriel.Size = new System.Drawing.Size(127, 36);
            this.btnGabriel.TabIndex = 5;
            this.btnGabriel.Text = "começar a comer";
            this.btnGabriel.UseVisualStyleBackColor = true;
            this.btnGabriel.Click += new System.EventHandler(this.button3_Click);
            // 
            // gabTD
            // 
            this.gabTD.Image = global::ProjetoRafa.Properties.Resources.token;
            this.gabTD.Location = new System.Drawing.Point(715, 238);
            this.gabTD.Name = "gabTD";
            this.gabTD.Size = new System.Drawing.Size(68, 59);
            this.gabTD.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gabTD.TabIndex = 15;
            this.gabTD.TabStop = false;
            this.gabTD.Visible = false;
            // 
            // lucasGSE
            // 
            this.lucasGSE.Image = global::ProjetoRafa.Properties.Resources.garfoS;
            this.lucasGSE.Location = new System.Drawing.Point(40, 367);
            this.lucasGSE.Name = "lucasGSE";
            this.lucasGSE.Size = new System.Drawing.Size(59, 63);
            this.lucasGSE.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.lucasGSE.TabIndex = 14;
            this.lucasGSE.TabStop = false;
            this.lucasGSE.Visible = false;
            // 
            // carolGSE
            // 
            this.carolGSE.Image = global::ProjetoRafa.Properties.Resources.garfoS;
            this.carolGSE.Location = new System.Drawing.Point(206, 84);
            this.carolGSE.Name = "carolGSE";
            this.carolGSE.Size = new System.Drawing.Size(59, 63);
            this.carolGSE.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.carolGSE.TabIndex = 13;
            this.carolGSE.TabStop = false;
            this.carolGSE.Visible = false;
            // 
            // gabGSE
            // 
            this.gabGSE.Image = global::ProjetoRafa.Properties.Resources.garfoS;
            this.gabGSE.Location = new System.Drawing.Point(457, 367);
            this.gabGSE.Name = "gabGSE";
            this.gabGSE.Size = new System.Drawing.Size(59, 63);
            this.gabGSE.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gabGSE.TabIndex = 12;
            this.gabGSE.TabStop = false;
            this.gabGSE.Visible = false;
            // 
            // lucasGLD
            // 
            this.lucasGLD.Image = global::ProjetoRafa.Properties.Resources.garfoL;
            this.lucasGLD.Location = new System.Drawing.Point(290, 307);
            this.lucasGLD.Name = "lucasGLD";
            this.lucasGLD.Size = new System.Drawing.Size(56, 54);
            this.lucasGLD.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.lucasGLD.TabIndex = 11;
            this.lucasGLD.TabStop = false;
            // 
            // carolGLD
            // 
            this.carolGLD.Image = global::ProjetoRafa.Properties.Resources.garfoL;
            this.carolGLD.Location = new System.Drawing.Point(493, 91);
            this.carolGLD.Name = "carolGLD";
            this.carolGLD.Size = new System.Drawing.Size(49, 65);
            this.carolGLD.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.carolGLD.TabIndex = 10;
            this.carolGLD.TabStop = false;
            // 
            // gabGLD
            // 
            this.gabGLD.Image = global::ProjetoRafa.Properties.Resources.garfoL;
            this.gabGLD.Location = new System.Drawing.Point(715, 304);
            this.gabGLD.Name = "gabGLD";
            this.gabGLD.Size = new System.Drawing.Size(59, 54);
            this.gabGLD.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gabGLD.TabIndex = 9;
            this.gabGLD.TabStop = false;
            this.gabGLD.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // gabrielH
            // 
            this.gabrielH.Image = global::ProjetoRafa.Properties.Resources.dormindo;
            this.gabrielH.Location = new System.Drawing.Point(531, 238);
            this.gabrielH.Name = "gabrielH";
            this.gabrielH.Size = new System.Drawing.Size(178, 123);
            this.gabrielH.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gabrielH.TabIndex = 8;
            this.gabrielH.TabStop = false;
            // 
            // carolineA
            // 
            this.carolineA.Image = global::ProjetoRafa.Properties.Resources.dormindo;
            this.carolineA.Location = new System.Drawing.Point(326, 26);
            this.carolineA.Name = "carolineA";
            this.carolineA.Size = new System.Drawing.Size(161, 106);
            this.carolineA.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.carolineA.TabIndex = 7;
            this.carolineA.TabStop = false;
            // 
            // lucasD
            // 
            this.lucasD.Image = global::ProjetoRafa.Properties.Resources.dormindo;
            this.lucasD.Location = new System.Drawing.Point(105, 238);
            this.lucasD.Name = "lucasD";
            this.lucasD.Size = new System.Drawing.Size(172, 120);
            this.lucasD.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.lucasD.TabIndex = 6;
            this.lucasD.TabStop = false;
            this.lucasD.Click += new System.EventHandler(this.lucassss_Click);
            // 
            // carolTE
            // 
            this.carolTE.Image = global::ProjetoRafa.Properties.Resources.token;
            this.carolTE.Location = new System.Drawing.Point(252, 17);
            this.carolTE.Name = "carolTE";
            this.carolTE.Size = new System.Drawing.Size(68, 59);
            this.carolTE.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.carolTE.TabIndex = 16;
            this.carolTE.TabStop = false;
            // 
            // lucasTE
            // 
            this.lucasTE.Image = global::ProjetoRafa.Properties.Resources.token;
            this.lucasTE.Location = new System.Drawing.Point(31, 238);
            this.lucasTE.Name = "lucasTE";
            this.lucasTE.Size = new System.Drawing.Size(68, 59);
            this.lucasTE.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.lucasTE.TabIndex = 17;
            this.lucasTE.TabStop = false;
            // 
            // carolTD
            // 
            this.carolTD.Image = global::ProjetoRafa.Properties.Resources.token;
            this.carolTD.Location = new System.Drawing.Point(493, 26);
            this.carolTD.Name = "carolTD";
            this.carolTD.Size = new System.Drawing.Size(68, 59);
            this.carolTD.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.carolTD.TabIndex = 18;
            this.carolTD.TabStop = false;
            this.carolTD.Visible = false;
            // 
            // lucasTD
            // 
            this.lucasTD.Image = global::ProjetoRafa.Properties.Resources.token;
            this.lucasTD.Location = new System.Drawing.Point(283, 238);
            this.lucasTD.Name = "lucasTD";
            this.lucasTD.Size = new System.Drawing.Size(68, 59);
            this.lucasTD.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.lucasTD.TabIndex = 19;
            this.lucasTD.TabStop = false;
            this.lucasTD.Visible = false;
            // 
            // gabTE
            // 
            this.gabTE.Image = global::ProjetoRafa.Properties.Resources.token;
            this.gabTE.Location = new System.Drawing.Point(457, 238);
            this.gabTE.Name = "gabTE";
            this.gabTE.Size = new System.Drawing.Size(68, 59);
            this.gabTE.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gabTE.TabIndex = 20;
            this.gabTE.TabStop = false;
            // 
            // carolGLE
            // 
            this.carolGLE.Image = global::ProjetoRafa.Properties.Resources.garfoL;
            this.carolGLE.Location = new System.Drawing.Point(271, 82);
            this.carolGLE.Name = "carolGLE";
            this.carolGLE.Size = new System.Drawing.Size(49, 65);
            this.carolGLE.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.carolGLE.TabIndex = 21;
            this.carolGLE.TabStop = false;
            this.carolGLE.Visible = false;
            // 
            // carolGSD
            // 
            this.carolGSD.Image = global::ProjetoRafa.Properties.Resources.garfoS;
            this.carolGSD.Location = new System.Drawing.Point(548, 93);
            this.carolGSD.Name = "carolGSD";
            this.carolGSD.Size = new System.Drawing.Size(59, 63);
            this.carolGSD.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.carolGSD.TabIndex = 22;
            this.carolGSD.TabStop = false;
            this.carolGSD.Visible = false;
            // 
            // gabGSD
            // 
            this.gabGSD.Image = global::ProjetoRafa.Properties.Resources.garfoS;
            this.gabGSD.Location = new System.Drawing.Point(715, 370);
            this.gabGSD.Name = "gabGSD";
            this.gabGSD.Size = new System.Drawing.Size(59, 63);
            this.gabGSD.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gabGSD.TabIndex = 23;
            this.gabGSD.TabStop = false;
            this.gabGSD.Visible = false;
            // 
            // gabGLE
            // 
            this.gabGLE.Image = global::ProjetoRafa.Properties.Resources.garfoL;
            this.gabGLE.Location = new System.Drawing.Point(466, 304);
            this.gabGLE.Name = "gabGLE";
            this.gabGLE.Size = new System.Drawing.Size(59, 54);
            this.gabGLE.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gabGLE.TabIndex = 24;
            this.gabGLE.TabStop = false;
            this.gabGLE.Visible = false;
            // 
            // lucasGSD
            // 
            this.lucasGSD.Image = global::ProjetoRafa.Properties.Resources.garfoS;
            this.lucasGSD.Location = new System.Drawing.Point(292, 367);
            this.lucasGSD.Name = "lucasGSD";
            this.lucasGSD.Size = new System.Drawing.Size(59, 63);
            this.lucasGSD.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.lucasGSD.TabIndex = 25;
            this.lucasGSD.TabStop = false;
            this.lucasGSD.Visible = false;
            // 
            // lucasGLE
            // 
            this.lucasGLE.Image = global::ProjetoRafa.Properties.Resources.garfoL;
            this.lucasGLE.Location = new System.Drawing.Point(43, 303);
            this.lucasGLE.Name = "lucasGLE";
            this.lucasGLE.Size = new System.Drawing.Size(56, 54);
            this.lucasGLE.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.lucasGLE.TabIndex = 26;
            this.lucasGLE.TabStop = false;
            this.lucasGLE.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(918, 514);
            this.Controls.Add(this.lucasGLE);
            this.Controls.Add(this.lucasGSD);
            this.Controls.Add(this.gabGLE);
            this.Controls.Add(this.gabGSD);
            this.Controls.Add(this.carolGSD);
            this.Controls.Add(this.carolGLE);
            this.Controls.Add(this.gabTE);
            this.Controls.Add(this.lucasTD);
            this.Controls.Add(this.carolTD);
            this.Controls.Add(this.lucasTE);
            this.Controls.Add(this.carolTE);
            this.Controls.Add(this.gabTD);
            this.Controls.Add(this.lucasGSE);
            this.Controls.Add(this.carolGSE);
            this.Controls.Add(this.gabGSE);
            this.Controls.Add(this.lucasGLD);
            this.Controls.Add(this.carolGLD);
            this.Controls.Add(this.gabGLD);
            this.Controls.Add(this.gabrielH);
            this.Controls.Add(this.carolineA);
            this.Controls.Add(this.lucasD);
            this.Controls.Add(this.btnGabriel);
            this.Controls.Add(this.btnCarol);
            this.Controls.Add(this.btnLucas);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.gabTD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lucasGSE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carolGSE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gabGSE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lucasGLD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carolGLD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gabGLD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gabrielH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carolineA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lucasD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carolTE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lucasTE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carolTD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lucasTD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gabTE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carolGLE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carolGSD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gabGSD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gabGLE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lucasGSD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lucasGLE)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnLucas;
        private System.Windows.Forms.Button btnCarol;
        private System.Windows.Forms.Button btnGabriel;
        private System.Windows.Forms.PictureBox lucasD;
        private System.Windows.Forms.PictureBox carolineA;
        private System.Windows.Forms.PictureBox gabrielH;
        private System.Windows.Forms.PictureBox gabGLD;
        private System.Windows.Forms.PictureBox carolGLD;
        private System.Windows.Forms.PictureBox lucasGLD;
        private System.Windows.Forms.PictureBox gabGSE;
        private System.Windows.Forms.PictureBox carolGSE;
        private System.Windows.Forms.PictureBox lucasGSE;
        private System.Windows.Forms.PictureBox gabTD;
        private System.Windows.Forms.PictureBox carolTE;
        private System.Windows.Forms.PictureBox lucasTE;
        private System.Windows.Forms.PictureBox carolTD;
        private System.Windows.Forms.PictureBox lucasTD;
        private System.Windows.Forms.PictureBox gabTE;
        private System.Windows.Forms.PictureBox carolGLE;
        private System.Windows.Forms.PictureBox carolGSD;
        private System.Windows.Forms.PictureBox gabGSD;
        private System.Windows.Forms.PictureBox gabGLE;
        private System.Windows.Forms.PictureBox lucasGSD;
        private System.Windows.Forms.PictureBox lucasGLE;
    }
}

