﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoRafa
{
    
    
    public partial class Form1 : Form
    {

        Filosofo lucas = null;
        Filosofo carol = null;
        Filosofo gabriel = null;

        public Form1()
        {
           
            InitializeComponent();

            lucas = new Filosofo();
            carol = new Filosofo();
            gabriel = new Filosofo();

            lucas.vizinhoDireita = gabriel;
            lucas.vizinhoEsquerda = carol;
            gabriel.vizinhoDireita = carol;
            gabriel.vizinhoEsquerda = lucas;
            carol.vizinhoEsquerda = lucas;
            carol.vizinhoDireita = gabriel;

        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (!lucas._isComendo) {
                lucas.comecarComer();

                if (lucas._isComendo) {
                    lucasD.Image = Properties.Resources.comendo;
                    btnLucas.Text = "Parar de comer";
                } else {
                    lucasD.Image = Properties.Resources.esperando;
                    btnLucas.Text = "esperando";
                    btnLucas.Enabled = false;
                }
                return;
            }

            if (lucas._isComendo) {
                lucasD.Image = Properties.Resources.dormindo;
                btnLucas.Text = "começar a comer";
            }
          


        }

        private void button2_Click(object sender, EventArgs e)
        {
            carolineA.Image = Properties.Resources.esperando;
            btnCarol.Text = "esperando";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            gabrielH.Image = Properties.Resources.esperando;
            btnGabriel.Text = "esperando";
            gabGLD.Hide();

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void lucassss_Click(object sender, EventArgs e)
        {

        }
    }
}
